package com.ice.bond_portfolio_risk_analyser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BondPortfolioRiskAnalyserApplicationTests {

	@Test
	void contextLoads() {
	}

}
