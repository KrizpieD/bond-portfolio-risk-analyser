package com.ice.bond_portfolio_risk_analyser.metrics.util;

public enum MetricType {
    YTM,
    DURATION,
    MODDEDDURATION
}
